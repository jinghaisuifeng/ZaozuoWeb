create procedure splitString(IN f_string varchar(1000), IN f_delimiter varchar(5))
  BEGIN
declare cnt int default 0;
declare i int default 0;
set cnt = func_split_TotalLength(f_string,f_delimiter);
DROP TABLE IF EXISTS `tmp_split`;
create temporary table `tmp_split` (`val_` varchar(128) not null) DEFAULT CHARSET=utf8;

while i < cnt
do
set i = i + 1;
insert into tmp_split(`val_`) values (func_split(f_string,f_delimiter,i));
end while;
END;

