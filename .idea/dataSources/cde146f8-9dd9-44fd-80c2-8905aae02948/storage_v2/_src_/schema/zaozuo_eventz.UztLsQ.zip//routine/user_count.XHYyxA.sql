create procedure user_count(IN uid mediumtext, OUT user_num int)
  BEGIN 
			select  count(*) INTO user_num from `user` where `user`.uid = uid;
		END;

